import 'bill_item_model.dart';

class Bill {
  final int? id;
  final String billNumber;
  final int? customerId;
  final String? customerName;
  final List<BillItem> items;
  final double subTotal;
  final double gstTotal;
  final double grandTotal;
  final double? discount;
  final double? paidAmount;
  final double? dueAmount;
  final String paymentMethod;
  final DateTime createdAt;
  final String? notes;

  Bill({
    this.id,
    required this.billNumber,
    this.customerId,
    this.customerName,
    required this.items,
    required this.subTotal,
    required this.gstTotal,
    required this.grandTotal,
    this.discount,
    this.paidAmount,
    this.dueAmount,
    this.paymentMethod = 'Cash',
    required this.createdAt,
    this.notes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'billNumber': billNumber,
      'customerId': customerId,
      'customerName': customerName,
      'subTotal': subTotal,
      'gstTotal': gstTotal,
      'grandTotal': grandTotal,
      'discount': discount,
      'paidAmount': paidAmount,
      'dueAmount': dueAmount,
      'paymentMethod': paymentMethod,
      'createdAt': createdAt.toIso8601String(),
      'notes': notes,
    };
  }

  factory Bill.fromMap(Map<String, dynamic> map) {
    return Bill(
      id: map['id'] as int?,
      billNumber: map['billNumber'] as String,
      customerId: map['customerId'] as int?,
      customerName: map['customerName'] as String?,
      items: [],
      subTotal: map['subTotal'] as double,
      gstTotal: map['gstTotal'] as double,
      grandTotal: map['grandTotal'] as double,
      discount: map['discount'] as double?,
      paidAmount: map['paidAmount'] as double?,
      dueAmount: map['dueAmount'] as double?,
      paymentMethod: map['paymentMethod'] as String? ?? 'Cash',
      createdAt: DateTime.parse(map['createdAt'] as String),
      notes: map['notes'] as String?,
    );
  }
}

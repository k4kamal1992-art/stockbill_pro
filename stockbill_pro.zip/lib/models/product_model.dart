class Product {
  final int? id;
  final String name;
  final String? barcode;
  final double purchasePrice;
  final double salePrice;
  final int stockQuantity;
  final String? unit;
  final String? category;
  final double? gstRate;
  final String? hsnCode;
  final String? description;

  Product({
    this.id,
    required this.name,
    this.barcode,
    required this.purchasePrice,
    required this.salePrice,
    required this.stockQuantity,
    this.unit,
    this.category,
    this.gstRate,
    this.hsnCode,
    this.description,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'barcode': barcode,
      'purchasePrice': purchasePrice,
      'salePrice': salePrice,
      'stockQuantity': stockQuantity,
      'unit': unit,
      'category': category,
      'gstRate': gstRate,
      'hsnCode': hsnCode,
      'description': description,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] as int?,
      name: map['name'] as String,
      barcode: map['barcode'] as String?,
      purchasePrice: map['purchasePrice'] as double,
      salePrice: map['salePrice'] as double,
      stockQuantity: map['stockQuantity'] as int,
      unit: map['unit'] as String?,
      category: map['category'] as String?,
      gstRate: map['gstRate'] as double?,
      hsnCode: map['hsnCode'] as String?,
      description: map['description'] as String?,
    );
  }

  Product copyWith({
    int? id,
    String? name,
    String? barcode,
    double? purchasePrice,
    double? salePrice,
    int? stockQuantity,
    String? unit,
    String? category,
    double? gstRate,
    String? hsnCode,
    String? description,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      barcode: barcode ?? this.barcode,
      purchasePrice: purchasePrice ?? this.purchasePrice,
      salePrice: salePrice ?? this.salePrice,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      unit: unit ?? this.unit,
      category: category ?? this.category,
      gstRate: gstRate ?? this.gstRate,
      hsnCode: hsnCode ?? this.hsnCode,
      description: description ?? this.description,
    );
  }
}

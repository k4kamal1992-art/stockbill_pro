import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/staff_model.dart';

class StaffProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;
  List<Staff> _staff = [];
  bool _isLoading = false;

  List<Staff> get staff => _staff;
  bool get isLoading => _isLoading;

  Future<void> loadStaff() async {
    _isLoading = true;
    notifyListeners();
    _staff = await _db.getAllStaff();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> addStaff(Staff member) async {
    await _db.insertStaff(member);
    await loadStaff();
  }

  Future<void> updateStaff(Staff member) async {
    await _db.updateStaff(member);
    await loadStaff();
  }

  Future<void> deleteStaff(int id) async {
    await _db.deleteStaff(id);
    await loadStaff();
  }
}

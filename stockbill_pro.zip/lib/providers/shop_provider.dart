import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/shop_model.dart';

class ShopProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;
  List<Shop> _shops = [];
  bool _isLoading = false;

  List<Shop> get shops => _shops;
  bool get isLoading => _isLoading;

  Future<void> loadShops() async {
    _isLoading = true;
    notifyListeners();
    _shops = await _db.getAllShops();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> addShop(Shop shop) async {
    await _db.insertShop(shop);
    await loadShops();
  }

  Future<void> updateShop(Shop shop) async {
    await _db.updateShop(shop);
    await loadShops();
  }

  Future<void> deleteShop(int id) async {
    await _db.deleteShop(id);
    await loadShops();
  }
}

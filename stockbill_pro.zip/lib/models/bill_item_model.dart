import 'product_model.dart';

class BillItem {
  final Product product;
  int quantity;
  double price;
  double? gstRate;

  BillItem({
    required this.product,
    required this.quantity,
    required this.price,
    this.gstRate,
  });

  double get total => price * quantity;

  double get gstAmount => total * (gstRate ?? 0) / 100;

  double get totalWithGst => total + gstAmount;

  Map<String, dynamic> toMap(int billId) {
    return {
      'billId': billId,
      'productId': product.id,
      'productName': product.name,
      'quantity': quantity,
      'price': price,
      'gstRate': gstRate,
      'total': total,
    };
  }
}

class StockTransaction {
  final int? id;
  final int productId;
  final String productName;
  final String type; // 'in' or 'out'
  final int quantity;
  final double? unitPrice;
  final String? notes;
  final DateTime date;

  StockTransaction({
    this.id,
    required this.productId,
    required this.productName,
    required this.type,
    required this.quantity,
    this.unitPrice,
    this.notes,
    required this.date,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'productId': productId,
      'productName': productName,
      'type': type,
      'quantity': quantity,
      'unitPrice': unitPrice,
      'notes': notes,
      'date': date.toIso8601String(),
    };
  }

  factory StockTransaction.fromMap(Map<String, dynamic> map) {
    return StockTransaction(
      id: map['id'] as int?,
      productId: map['productId'] as int,
      productName: map['productName'] as String,
      type: map['type'] as String,
      quantity: map['quantity'] as int,
      unitPrice: map['unitPrice'] as double?,
      notes: map['notes'] as String?,
      date: DateTime.parse(map['date'] as String),
    );
  }
}

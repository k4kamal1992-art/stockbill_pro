class Staff {
  final int? id;
  final String name;
  final String? phone;
  final String? email;
  final String? role;
  final double? salary;
  final bool isActive;

  Staff({
    this.id,
    required this.name,
    this.phone,
    this.email,
    this.role,
    this.salary,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'email': email,
      'role': role,
      'salary': salary,
      'isActive': isActive ? 1 : 0,
    };
  }

  factory Staff.fromMap(Map<String, dynamic> map) {
    return Staff(
      id: map['id'] as int?,
      name: map['name'] as String,
      phone: map['phone'] as String?,
      email: map['email'] as String?,
      role: map['role'] as String?,
      salary: map['salary'] as double?,
      isActive: map['isActive'] == 1,
    );
  }
}

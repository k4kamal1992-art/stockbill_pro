class Shop {
  final int? id;
  final String name;
  final String? address;
  final String? phone;
  final String? email;
  final String? gstNumber;
  final String? logoPath;
  final bool isActive;

  Shop({
    this.id,
    required this.name,
    this.address,
    this.phone,
    this.email,
    this.gstNumber,
    this.logoPath,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'address': address,
      'phone': phone,
      'email': email,
      'gstNumber': gstNumber,
      'logoPath': logoPath,
      'isActive': isActive ? 1 : 0,
    };
  }

  factory Shop.fromMap(Map<String, dynamic> map) {
    return Shop(
      id: map['id'] as int?,
      name: map['name'] as String,
      address: map['address'] as String?,
      phone: map['phone'] as String?,
      email: map['email'] as String?,
      gstNumber: map['gstNumber'] as String?,
      logoPath: map['logoPath'] as String?,
      isActive: map['isActive'] == 1,
    );
  }
}

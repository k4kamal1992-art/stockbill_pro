package com.stockbill.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

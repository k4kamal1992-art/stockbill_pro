import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/bill_provider.dart';
import '../providers/product_provider.dart';
import '../providers/customer_provider.dart';
import '../models/bill_model.dart';
import '../models/bill_item_model.dart';
import '../models/product_model.dart';
import '../models/customer_model.dart';

class BillingScreen extends StatefulWidget {
  const BillingScreen({super.key});

  @override
  State<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends State<BillingScreen> {
  final _searchCtrl = TextEditingController();
  Customer? _selectedCustomer;
  final _discountCtrl = TextEditingController(text: '0');
  final _paidCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  String _paymentMethod = 'Cash';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProductProvider>().loadProducts();
      context.read<CustomerProvider>().loadCustomers();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _discountCtrl.dispose();
    _paidCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Bill'),
        actions: [
          TextButton.icon(
            onPressed: _currentItems.isEmpty ? null : _saveBill,
            icon: const Icon(Icons.save, color: Colors.white),
            label: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: Column(
        children: [
          // Customer & Search Section
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                // Customer Selector
                _buildCustomerSelector(),
                const SizedBox(height: 10),
                // Product Search
                TextField(
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    hintText: 'Search product by name or barcode',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchCtrl.clear();
                        context.read<ProductProvider>().searchProducts('');
                      },
                    ),
                    border: const OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    context.read<ProductProvider>().searchProducts(value);
                  },
                ),
                // Search Results
                Consumer<ProductProvider>(
                  builder: (context, provider, child) {
                    final products = provider.products;
                    if (_searchCtrl.text.isEmpty || products.isEmpty) {
                      return const SizedBox.shrink();
                    }
                    return Container(
                      constraints: const BoxConstraints(maxHeight: 200),
                      margin: const EdgeInsets.only(top: 4),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: products.length,
                        itemBuilder: (context, index) {
                          final p = products[index];
                          return ListTile(
                            dense: true,
                            title: Text(p.name),
                            subtitle: Text('Stock: ${p.stockQuantity} | Rs. ${p.salePrice}'),
                            onTap: () => _addProductToBill(p),
                          );
                        },
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          // Bill Items
          Expanded(
            child: Consumer<BillProvider>(
              builder: (context, provider, child) {
                final items = provider.currentItems;
                if (items.isEmpty) {
                  return const Center(
                    child: Text('Add products to create a bill',
                        style: TextStyle(color: Colors.grey)),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return Card(
                      child: ListTile(
                        title: Text(item.product.name),
                        subtitle: Text(
                            'Rs. ${item.price.toStringAsFixed(2)} x ${item.quantity}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.remove_circle_outline),
                              onPressed: () {
                                if (item.quantity > 1) {
                                  provider.updateItemQuantity(
                                      index, item.quantity - 1);
                                }
                              },
                            ),
                            Text('${item.quantity}',
                                style: const TextStyle(fontSize: 16)),
                            IconButton(
                              icon: const Icon(Icons.add_circle_outline),
                              onPressed: () {
                                if (item.quantity >= item.product.stockQuantity) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Only ${item.product.stockQuantity} units available')),
                                  );
                                  return;
                                }
                                provider.updateItemQuantity(index, item.quantity + 1);
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => provider.removeItem(index),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // Totals Section
          Consumer<BillProvider>(
            builder: (context, provider, child) {
              if (provider.currentItems.isEmpty) return const SizedBox.shrink();

              return Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  border: Border(top: BorderSide(color: Colors.grey.shade300)),
                ),
                child: Column(
                  children: [
                    _buildTotalRow('Subtotal:', provider.subTotal),
                    _buildTotalRow('GST:', provider.gstTotal),
                    Row(
                      children: [
                        const Text('Discount:'),
                        const SizedBox(width: 8),
                        SizedBox(
                          width: 80,
                          child: TextField(
                            controller: _discountCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              prefixText: 'Rs. ',
                              isDense: true,
                            ),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                      ],
                    ),
                    const Divider(),
                    _buildTotalRow(
                      'Grand Total:',
                      provider.grandTotal - (_discountAmount),
                      isBold: true,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _paidCtrl,
                            decoration: const InputDecoration(
                              labelText: 'Paid Amount',
                              prefixText: 'Rs. ',
                              border: OutlineInputBorder(),
                            ),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                        const SizedBox(width: 12),
                        DropdownButton<String>(
                          value: _paymentMethod,
                          items: ['Cash', 'Card', 'UPI', 'Credit']
                              .map((m) => DropdownMenuItem(
                                    value: m,
                                    child: Text(m),
                                  ))
                              .toList(),
                          onChanged: (v) => setState(() => _paymentMethod = v!),
                        ),
                      ],
                    ),
                    if (_dueAmount > 0)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          'Due: Rs. ${_dueAmount.toStringAsFixed(2)}',
                          style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerSelector() {
    return Consumer<CustomerProvider>(
      builder: (context, provider, child) {
        return InkWell(
          onTap: () => _showCustomerPicker(provider.customers),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade400),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Icon(Icons.person_outline),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _selectedCustomer?.name ?? 'Select Customer (Optional)',
                    style: TextStyle(
                      color: _selectedCustomer == null
                          ? Colors.grey.shade600
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
                if (_selectedCustomer != null)
                  IconButton(
                    icon: const Icon(Icons.clear, size: 18),
                    onPressed: () => setState(() => _selectedCustomer = null),
                  ),
                const Icon(Icons.arrow_drop_down),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showCustomerPicker(List<Customer> customers) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => ListView.builder(
        itemCount: customers.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return ListTile(
              leading: const Icon(Icons.person_add),
              title: const Text('Walk-in Customer'),
              onTap: () {
                setState(() => _selectedCustomer = null);
                Navigator.pop(ctx);
              },
            );
          }
          final c = customers[index - 1];
          return ListTile(
            title: Text(c.name),
            subtitle: c.phone != null ? Text(c.phone!) : null,
            onTap: () {
              setState(() => _selectedCustomer = c);
              Navigator.pop(ctx);
            },
          );
        },
      ),
    );
  }

  void _addProductToBill(Product product) {
    if (product.stockQuantity <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Product out of stock')),
      );
      return;
    }

    final provider = context.read<BillProvider>();
    final existing = provider.currentItems.where((item) => item.product.id == product.id);
    final alreadyInBill = existing.isEmpty ? 0 : existing.first.quantity;
    if (alreadyInBill >= product.stockQuantity) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Only ${product.stockQuantity} units available')),
      );
      return;
    }
    provider.addItem(BillItem(
      product: product,
      quantity: 1,
      price: product.salePrice,
      gstRate: product.gstRate,
    ));

    _searchCtrl.clear();
    context.read<ProductProvider>().searchProducts('');

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${product.name} added to bill')),
    );
  }

  List<BillItem> get _currentItems => context.read<BillProvider>().currentItems;

  double get _discountAmount {
    final text = _discountCtrl.text.trim();
    return double.tryParse(text) ?? 0;
  }

  double get _dueAmount {
    final provider = context.read<BillProvider>();
    final paid = double.tryParse(_paidCtrl.text.trim()) ?? 0;
    return provider.grandTotal - _discountAmount - paid;
  }

  Widget _buildTotalRow(String label, double value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            'Rs. ${value.toStringAsFixed(2)}',
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              fontSize: isBold ? 18 : 14,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _saveBill() async {
    final provider = context.read<BillProvider>();
    if (provider.currentItems.isEmpty) return;

    final discount = double.tryParse(_discountCtrl.text.trim()) ?? 0;
    final paid = double.tryParse(_paidCtrl.text.trim().isEmpty ? '0' : _paidCtrl.text.trim()) ?? double.nan;
    final totalBeforeDiscount = provider.grandTotal;
    final finalTotal = totalBeforeDiscount - discount;
    if (!discount.isFinite || discount < 0 || discount > totalBeforeDiscount) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a valid discount between Rs. 0 and the bill total')),
      );
      return;
    }
    if (!paid.isFinite || paid < 0 || paid > finalTotal) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a valid paid amount not greater than the final total')),
      );
      return;
    }
    for (final item in provider.currentItems) {
      if (item.quantity <= 0 || item.quantity > item.product.stockQuantity) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Insufficient stock for ${item.product.name}. Please refresh products.')),
        );
        await context.read<ProductProvider>().loadProducts();
        return;
      }
    }

    final now = DateTime.now();
    final billNumber = 'BILL-${now.millisecondsSinceEpoch}';

    final grandTotal = finalTotal;

    final bill = Bill(
      billNumber: billNumber,
      customerId: _selectedCustomer?.id,
      customerName: _selectedCustomer?.name ?? 'Walk-in Customer',
      items: provider.currentItems,
      subTotal: provider.subTotal,
      gstTotal: provider.gstTotal,
      grandTotal: grandTotal,
      discount: discount,
      paidAmount: paid,
      dueAmount: grandTotal - paid,
      paymentMethod: _paymentMethod,
      createdAt: now,
      notes: _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim(),
    );

    try {
      await provider.saveBill(bill);
      await context.read<ProductProvider>().loadProducts();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bill saved successfully')),
      );
      provider.clearItems();
      setState(() {
        _selectedCustomer = null;
        _discountCtrl.text = '0';
        _paidCtrl.clear();
        _notesCtrl.clear();
      });
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save bill: ${error.toString().replaceFirst("Bad state: ", "")}')),
      );
      await context.read<ProductProvider>().loadProducts();
    }
  }
}

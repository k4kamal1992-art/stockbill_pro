import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../providers/bill_provider.dart';
import '../providers/product_provider.dart';
import '../database/database_helper.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int _selectedReport = 0;
  Map<String, dynamic> _stats = {};
  bool _isLoading = true;

  final List<String> _reportTitles = [
    'Sales Overview',
    'Stock Status',
    'Recent Bills',
  ];

  @override
  void initState() {
    super.initState();
    _loadStats();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<BillProvider>().loadBills();
      context.read<ProductProvider>().loadProducts();
    });
  }

  Future<void> _loadStats() async {
    final stats = await DatabaseHelper.instance.getDashboardStats();
    setState(() {
      _stats = stats;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reports'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Report Type Selector
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: SegmentedButton<int>(
                    segments: [
                      ButtonSegment(
                        value: 0,
                        label: const Text('Sales'),
                        icon: Icon(Icons.show_chart,
                            size: _selectedReport == 0 ? 22 : 18),
                      ),
                      ButtonSegment(
                        value: 1,
                        label: const Text('Stock'),
                        icon: Icon(Icons.inventory,
                            size: _selectedReport == 1 ? 22 : 18),
                      ),
                      ButtonSegment(
                        value: 2,
                        label: const Text('Bills'),
                        icon: Icon(Icons.receipt,
                            size: _selectedReport == 2 ? 22 : 18),
                      ),
                    ],
                    selected: {_selectedReport},
                    onSelectionChanged: (Set<int> newSelection) {
                      setState(() {
                        _selectedReport = newSelection.first;
                      });
                    },
                  ),
                ),

                // Report Content
                Expanded(
                  child: _buildReportContent(),
                ),
              ],
            ),
    );
  }

  Widget _buildReportContent() {
    switch (_selectedReport) {
      case 0:
        return _buildSalesReport();
      case 1:
        return _buildStockReport();
      case 2:
        return _buildBillsReport();
      default:
        return const Center(child: Text('Select a report'));
    }
  }

  Widget _buildSalesReport() {
    return Consumer<BillProvider>(
      builder: (context, provider, child) {
        final bills = provider.bills;

        if (bills.isEmpty) {
          return const Center(
            child: Text('No sales data available',
                style: TextStyle(color: Colors.grey)),
          );
        }

        // Calculate total sales
        final totalSales = bills.fold<double>(
            0, (sum, b) => sum + b.grandTotal);

        // Group by payment method
        final paymentStats = <String, double>{};
        for (var bill in bills) {
          paymentStats[bill.paymentMethod] =
              (paymentStats[bill.paymentMethod] ?? 0) + bill.grandTotal;
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Summary Cards
              Row(
                children: [
                  Expanded(
                    child: _ReportSummaryCard(
                      title: 'Total Sales',
                      value: 'Rs. ${totalSales.toStringAsFixed(2)}',
                      icon: Icons.currency_rupee,
                      color: Colors.green,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ReportSummaryCard(
                      title: 'Total Bills',
                      value: '${bills.length}',
                      icon: Icons.receipt_long,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Payment Method Breakdown
              const Text(
                'Payment Methods',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              ...paymentStats.entries.map((entry) {
                final percentage = totalSales > 0
                    ? (entry.value / totalSales * 100).toStringAsFixed(1)
                    : '0';
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: _getPaymentColor(entry.key),
                      child: Icon(
                        _getPaymentIcon(entry.key),
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    title: Text(entry.key),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'Rs. ${entry.value.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          '$percentage%',
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),

              const SizedBox(height: 24),

              // Simple Bar Chart
              if (bills.length >= 2) ...[
                const Text(
                  'Recent Sales Trend',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 200,
                  child: _buildSimpleBarChart(bills.take(10).toList()),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildStockReport() {
    return Consumer<ProductProvider>(
      builder: (context, provider, child) {
        final products = provider.products;

        if (products.isEmpty) {
          return const Center(
            child: Text('No products available',
                style: TextStyle(color: Colors.grey)),
          );
        }

        final lowStock = products.where((p) => p.stockQuantity <= 5).toList();
        final totalStock = products.fold<int>(
            0, (sum, p) => sum + p.stockQuantity);

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: _ReportSummaryCard(
                      title: 'Total Products',
                      value: '${products.length}',
                      icon: Icons.inventory_2,
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ReportSummaryCard(
                      title: 'Total Stock',
                      value: '$totalStock',
                      icon: Icons.warehouse,
                      color: Colors.orange,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _ReportSummaryCard(
                title: 'Low Stock Items',
                value: '${lowStock.length}',
                icon: Icons.warning_amber,
                color: Colors.red,
              ),

              const SizedBox(height: 24),

              // Stock List
              const Text(
                'Stock Details',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              ...products.map((p) {
                final isLow = p.stockQuantity <= 5;
                final stockPercent = p.stockQuantity > 100
                    ? 1.0
                    : p.stockQuantity / 100.0;

                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                p.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: isLow ? Colors.red : Colors.green,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                '${p.stockQuantity} ${p.unit ?? 'pcs'}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(
                          value: stockPercent,
                          backgroundColor: Colors.grey.shade200,
                          valueColor: AlwaysStoppedAnimation(
                            isLow ? Colors.red : Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBillsReport() {
    return Consumer<BillProvider>(
      builder: (context, provider, child) {
        final bills = provider.bills;

        if (bills.isEmpty) {
          return const Center(
            child: Text('No bills available',
                style: TextStyle(color: Colors.grey)),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: bills.length,
          itemBuilder: (context, index) {
            final bill = bills[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 8),
                leading: CircleAvatar(
                  backgroundColor: Colors.blue.shade100,
                  child: const Icon(Icons.receipt, color: Colors.blue),
                ),
                title: Text(
                  bill.billNumber,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(bill.customerName ?? 'Walk-in'),
                    Text(
                      DateFormat('dd MMM yyyy, hh:mm a')
                          .format(bill.createdAt),
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: _getPaymentColor(bill.paymentMethod)
                                .withOpacity(0.2),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            bill.paymentMethod,
                            style: TextStyle(
                              fontSize: 11,
                              color: _getPaymentColor(bill.paymentMethod),
                            ),
                          ),
                        ),
                        if ((bill.dueAmount ?? 0) > 0) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.red.shade100,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              'Due: Rs. ${bill.dueAmount!.toStringAsFixed(0)}',
                              style: const TextStyle(
                                fontSize: 11,
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
                trailing: Text(
                  'Rs. ${bill.grandTotal.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSimpleBarChart(List<dynamic> bills) {
    final data = bills.reversed.toList();
    final maxValue = data
        .map((b) => b.grandTotal)
        .reduce((a, b) => a > b ? a : b);

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: maxValue * 1.2,
        barTouchData: BarTouchData(enabled: false),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                final index = value.toInt();
                if (index >= 0 && index < data.length) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      '${index + 1}',
                      style: const TextStyle(fontSize: 10),
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (value, meta) {
                return Text(
                  value.toStringAsFixed(0),
                  style: const TextStyle(fontSize: 10),
                );
              },
            ),
          ),
          topTitles:
              const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles:
              const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        gridData: const FlGridData(show: false),
        barGroups: data.asMap().entries.map((entry) {
          return BarChartGroupData(
            x: entry.key,
            barRods: [
              BarChartRodData(
                toY: entry.value.grandTotal,
                color: Colors.blue,
                width: 16,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(4),
                ),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }

  Color _getPaymentColor(String method) {
    switch (method) {
      case 'Cash':
        return Colors.green;
      case 'Card':
        return Colors.blue;
      case 'UPI':
        return Colors.purple;
      case 'Credit':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  IconData _getPaymentIcon(String method) {
    switch (method) {
      case 'Cash':
        return Icons.money;
      case 'Card':
        return Icons.credit_card;
      case 'UPI':
        return Icons.phone_android;
      case 'Credit':
        return Icons.account_balance_wallet;
      default:
        return Icons.payment;
    }
  }
}

class _ReportSummaryCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const _ReportSummaryCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 12),
            Text(
              value,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/product_model.dart';
import '../models/customer_model.dart';
import '../models/bill_model.dart';
import '../models/bill_item_model.dart';
import '../models/shop_model.dart';
import '../models/staff_model.dart';
import '../models/expense_model.dart';
import '../models/supplier_model.dart';
import '../models/stock_transaction_model.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('stockbill.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        barcode TEXT,
        purchasePrice REAL NOT NULL,
        salePrice REAL NOT NULL,
        stockQuantity INTEGER NOT NULL DEFAULT 0,
        unit TEXT,
        category TEXT,
        gstRate REAL,
        hsnCode TEXT,
        description TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        dueAmount REAL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE bills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        billNumber TEXT NOT NULL,
        customerId INTEGER,
        customerName TEXT,
        subTotal REAL NOT NULL,
        gstTotal REAL NOT NULL,
        grandTotal REAL NOT NULL,
        discount REAL,
        paidAmount REAL,
        dueAmount REAL,
        paymentMethod TEXT,
        createdAt TEXT NOT NULL,
        notes TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE bill_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        billId INTEGER NOT NULL,
        productId INTEGER,
        productName TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL,
        gstRate REAL,
        total REAL NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE shops (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        address TEXT,
        phone TEXT,
        email TEXT,
        gstNumber TEXT,
        logoPath TEXT,
        isActive INTEGER DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE staff (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        role TEXT,
        salary REAL,
        isActive INTEGER DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        category TEXT,
        description TEXT,
        date TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        companyName TEXT,
        dueAmount REAL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE stock_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        productId INTEGER NOT NULL,
        productName TEXT NOT NULL,
        type TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        unitPrice REAL,
        notes TEXT,
        date TEXT NOT NULL
      )
    ''');
  }

  // ==================== PRODUCTS ====================
  Future<int> insertProduct(Product product) async {
    final db = await database;
    return await db.insert('products', product.toMap());
  }

  Future<List<Product>> getAllProducts() async {
    final db = await database;
    final maps = await db.query('products', orderBy: 'name ASC');
    return maps.map((m) => Product.fromMap(m)).toList();
  }

  Future<Product?> getProduct(int id) async {
    final db = await database;
    final maps = await db.query('products', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) return Product.fromMap(maps.first);
    return null;
  }

  Future<int> updateProduct(Product product) async {
    final db = await database;
    return await db.update('products', product.toMap(),
        where: 'id = ?', whereArgs: [product.id]);
  }

  Future<int> deleteProduct(int id) async {
    final db = await database;
    return await db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Product>> searchProducts(String query) async {
    final db = await database;
    final maps = await db.query('products',
        where: 'name LIKE ? OR barcode LIKE ?',
        whereArgs: ['%$query%', '%$query%'],
        orderBy: 'name ASC');
    return maps.map((m) => Product.fromMap(m)).toList();
  }

  // ==================== CUSTOMERS ====================
  Future<int> insertCustomer(Customer customer) async {
    final db = await database;
    return await db.insert('customers', customer.toMap());
  }

  Future<List<Customer>> getAllCustomers() async {
    final db = await database;
    final maps = await db.query('customers', orderBy: 'name ASC');
    return maps.map((m) => Customer.fromMap(m)).toList();
  }

  Future<int> updateCustomer(Customer customer) async {
    final db = await database;
    return await db.update('customers', customer.toMap(),
        where: 'id = ?', whereArgs: [customer.id]);
  }

  Future<int> deleteCustomer(int id) async {
    final db = await database;
    return await db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== BILLS ====================
  Future<int> insertBill(Bill bill) async {
    final db = await database;
    return await db.transaction((txn) async {
      final billId = await txn.insert('bills', bill.toMap());
      // Validate and update inventory inside the same transaction so a bill
      // cannot be saved with insufficient stock or a partially updated stock.
      for (final item in bill.items) {
        final productId = item.product.id;
        if (productId != null) {
          final rows = await txn.query(
            'products',
            columns: ['id', 'name', 'stockQuantity'],
            where: 'id = ?',
            whereArgs: [productId],
            limit: 1,
          );
          if (rows.isEmpty) {
            throw StateError('Product "${item.product.name}" no longer exists.');
          }
          final currentStock = (rows.first['stockQuantity'] as num).toInt();
          if (item.quantity <= 0 || currentStock < item.quantity) {
            throw StateError(
              'Insufficient stock for "${item.product.name}". Available: $currentStock.',
            );
          }
        }
      }

      for (final item in bill.items) {
        await txn.insert('bill_items', item.toMap(billId));
        final productId = item.product.id;
        if (productId != null) {
          final changed = await txn.rawUpdate(
            'UPDATE products SET stockQuantity = stockQuantity - ? '
            'WHERE id = ? AND stockQuantity >= ?',
            [item.quantity, productId, item.quantity],
          );
          if (changed != 1) {
            throw StateError('Stock changed while saving the bill. Please try again.');
          }
        }
      }
      return billId;
    });
  }

  Future<List<Bill>> getAllBills() async {
    final db = await database;
    final maps = await db.query('bills', orderBy: 'createdAt DESC');
    return maps.map((m) => Bill.fromMap(m)).toList();
  }

  Future<Bill?> getBillWithItems(int billId) async {
    final db = await database;
    final billMaps = await db.query('bills', where: 'id = ?', whereArgs: [billId]);
    if (billMaps.isEmpty) return null;

    final bill = Bill.fromMap(billMaps.first);
    final itemMaps = await db.query('bill_items', where: 'billId = ?', whereArgs: [billId]);

    final items = itemMaps.map((m) {
      final product = Product(
        id: m['productId'] as int?,
        name: m['productName'] as String,
        purchasePrice: 0,
        salePrice: m['price'] as double,
        stockQuantity: 0,
      );
      return BillItem(
        product: product,
        quantity: m['quantity'] as int,
        price: m['price'] as double,
        gstRate: m['gstRate'] as double?,
      );
    }).toList();

    return Bill(
      id: bill.id,
      billNumber: bill.billNumber,
      customerId: bill.customerId,
      customerName: bill.customerName,
      items: items,
      subTotal: bill.subTotal,
      gstTotal: bill.gstTotal,
      grandTotal: bill.grandTotal,
      discount: bill.discount,
      paidAmount: bill.paidAmount,
      dueAmount: bill.dueAmount,
      paymentMethod: bill.paymentMethod,
      createdAt: bill.createdAt,
      notes: bill.notes,
    );
  }

  // ==================== SHOPS ====================
  Future<int> insertShop(Shop shop) async {
    final db = await database;
    return await db.insert('shops', shop.toMap());
  }

  Future<List<Shop>> getAllShops() async {
    final db = await database;
    final maps = await db.query('shops', orderBy: 'name ASC');
    return maps.map((m) => Shop.fromMap(m)).toList();
  }

  Future<int> updateShop(Shop shop) async {
    final db = await database;
    return await db.update('shops', shop.toMap(),
        where: 'id = ?', whereArgs: [shop.id]);
  }

  Future<int> deleteShop(int id) async {
    final db = await database;
    return await db.delete('shops', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== STAFF ====================
  Future<int> insertStaff(Staff staff) async {
    final db = await database;
    return await db.insert('staff', staff.toMap());
  }

  Future<List<Staff>> getAllStaff() async {
    final db = await database;
    final maps = await db.query('staff', orderBy: 'name ASC');
    return maps.map((m) => Staff.fromMap(m)).toList();
  }

  Future<int> updateStaff(Staff staff) async {
    final db = await database;
    return await db.update('staff', staff.toMap(),
        where: 'id = ?', whereArgs: [staff.id]);
  }

  Future<int> deleteStaff(int id) async {
    final db = await database;
    return await db.delete('staff', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== EXPENSES ====================
  Future<int> insertExpense(Expense expense) async {
    final db = await database;
    return await db.insert('expenses', expense.toMap());
  }

  Future<List<Expense>> getAllExpenses() async {
    final db = await database;
    final maps = await db.query('expenses', orderBy: 'date DESC');
    return maps.map((m) => Expense.fromMap(m)).toList();
  }

  Future<int> updateExpense(Expense expense) async {
    final db = await database;
    return await db.update('expenses', expense.toMap(),
        where: 'id = ?', whereArgs: [expense.id]);
  }

  Future<int> deleteExpense(int id) async {
    final db = await database;
    return await db.delete('expenses', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== SUPPLIERS ====================
  Future<int> insertSupplier(Supplier supplier) async {
    final db = await database;
    return await db.insert('suppliers', supplier.toMap());
  }

  Future<List<Supplier>> getAllSuppliers() async {
    final db = await database;
    final maps = await db.query('suppliers', orderBy: 'name ASC');
    return maps.map((m) => Supplier.fromMap(m)).toList();
  }

  Future<int> updateSupplier(Supplier supplier) async {
    final db = await database;
    return await db.update('suppliers', supplier.toMap(),
        where: 'id = ?', whereArgs: [supplier.id]);
  }

  Future<int> deleteSupplier(int id) async {
    final db = await database;
    return await db.delete('suppliers', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== STOCK TRANSACTIONS ====================
  Future<int> insertStockTransaction(StockTransaction txn) async {
    final db = await database;
    return await db.insert('stock_transactions', txn.toMap());
  }

  Future<List<StockTransaction>> getStockTransactions(int productId) async {
    final db = await database;
    final maps = await db.query('stock_transactions',
        where: 'productId = ?',
        whereArgs: [productId],
        orderBy: 'date DESC');
    return maps.map((m) => StockTransaction.fromMap(m)).toList();
  }

  // ==================== DASHBOARD STATS ====================
  Future<Map<String, dynamic>> getDashboardStats() async {
    final db = await database;

    final productCount = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM products'));
    final customerCount = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM customers'));
    final billCount = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM bills'));

    final today = DateTime.now();
    final todayStr = today.toIso8601String().substring(0, 10);
    final todaySales = await db.rawQuery(
        "SELECT SUM(grandTotal) as total FROM bills WHERE createdAt LIKE ?",
        ['$todayStr%']);

    final lowStock = await db.rawQuery(
        'SELECT COUNT(*) FROM products WHERE stockQuantity <= 5');

    final totalExpense = await db.rawQuery(
        'SELECT SUM(amount) as total FROM expenses');

    final totalDue = await db.rawQuery(
        'SELECT SUM(dueAmount) as total FROM customers');

    return {
      'productCount': productCount ?? 0,
      'customerCount': customerCount ?? 0,
      'billCount': billCount ?? 0,
      'todaySales': (todaySales.first['total'] as double?) ?? 0.0,
      'lowStock': Sqflite.firstIntValue(lowStock) ?? 0,
      'totalExpense': (totalExpense.first['total'] as double?) ?? 0.0,
      'totalDue': (totalDue.first['total'] as double?) ?? 0.0,
    };
  }

  Future close() async {
    final db = await database;
    db.close();
  }
}

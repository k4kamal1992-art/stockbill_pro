import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/supplier_model.dart';

class SupplierProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;
  List<Supplier> _suppliers = [];
  bool _isLoading = false;

  List<Supplier> get suppliers => _suppliers;
  bool get isLoading => _isLoading;

  Future<void> loadSuppliers() async {
    _isLoading = true;
    notifyListeners();
    _suppliers = await _db.getAllSuppliers();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> addSupplier(Supplier supplier) async {
    await _db.insertSupplier(supplier);
    await loadSuppliers();
  }

  Future<void> updateSupplier(Supplier supplier) async {
    await _db.updateSupplier(supplier);
    await loadSuppliers();
  }

  Future<void> deleteSupplier(int id) async {
    await _db.deleteSupplier(id);
    await loadSuppliers();
  }
}

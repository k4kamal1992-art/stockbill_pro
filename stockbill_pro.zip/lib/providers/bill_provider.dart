import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/bill_model.dart';
import '../models/bill_item_model.dart';

class BillProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;
  List<Bill> _bills = [];
  List<BillItem> _currentItems = [];
  bool _isLoading = false;

  List<Bill> get bills => _bills;
  List<BillItem> get currentItems => _currentItems;
  bool get isLoading => _isLoading;

  double get subTotal => _currentItems.fold(0, (sum, item) => sum + item.total);

  double get gstTotal => _currentItems.fold(0, (sum, item) => sum + item.gstAmount);

  double get grandTotal => subTotal + gstTotal;

  Future<void> loadBills() async {
    _isLoading = true;
    notifyListeners();
    _bills = await _db.getAllBills();
    _isLoading = false;
    notifyListeners();
  }

  void addItem(BillItem item) {
    final existingIndex = _currentItems.indexWhere(
        (i) => i.product.id == item.product.id);
    if (existingIndex >= 0) {
      final requested = _currentItems[existingIndex].quantity + item.quantity;
      if (requested > item.product.stockQuantity) return;
      _currentItems[existingIndex].quantity = requested;
    } else {
      if (item.quantity <= 0 || item.quantity > item.product.stockQuantity) return;
      _currentItems.add(item);
    }
    notifyListeners();
  }

  void removeItem(int index) {
    _currentItems.removeAt(index);
    notifyListeners();
  }

  void updateItemQuantity(int index, int quantity) {
    if (quantity > 0 && quantity <= _currentItems[index].product.stockQuantity) {
      _currentItems[index].quantity = quantity;
      notifyListeners();
    }
  }

  void clearItems() {
    _currentItems = [];
    notifyListeners();
  }

  Future<void> saveBill(Bill bill) async {
    await _db.insertBill(bill);
    _currentItems = [];
    await loadBills();
  }

  Future<Bill?> getBillWithItems(int billId) async {
    return await _db.getBillWithItems(billId);
  }
}

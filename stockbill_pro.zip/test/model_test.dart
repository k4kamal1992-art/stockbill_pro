import 'package:flutter_test/flutter_test.dart';
import '../lib/models/product_model.dart';
import '../lib/models/bill_item_model.dart';
import '../lib/models/stock_transaction_model.dart';

void main() {
  group('Product model', () {
    test('converts to and from a map without losing fields', () {
      final product = Product(
        id: 7,
        name: 'Rice',
        barcode: '890123',
        purchasePrice: 42.5,
        salePrice: 50.0,
        stockQuantity: 12,
        unit: 'kg',
        category: 'Grocery',
        gstRate: 5.0,
        hsnCode: '1006',
        description: 'Test product',
      );
      final restored = Product.fromMap(product.toMap());
      expect(restored.id, 7);
      expect(restored.name, 'Rice');
      expect(restored.salePrice, 50.0);
      expect(restored.stockQuantity, 12);
      expect(restored.gstRate, 5.0);
    });
  });

  group('BillItem calculations', () {
    test('calculates subtotal, GST, and total including GST', () {
      final product = Product(id: 1, name: 'Notebook', purchasePrice: 20.0, salePrice: 30.0, stockQuantity: 10);
      final item = BillItem(product: product, quantity: 3, price: 30.0, gstRate: 5.0);
      expect(item.total, 90.0);
      expect(item.gstAmount, 4.5);
      expect(item.totalWithGst, 94.5);
    });

    test('treats missing GST rate as zero', () {
      final product = Product(name: 'Pen', purchasePrice: 5.0, salePrice: 10.0, stockQuantity: 5);
      final item = BillItem(product: product, quantity: 2, price: 10.0);
      expect(item.gstAmount, 0.0);
      expect(item.totalWithGst, 20.0);
    });
  });

  test('stock transaction preserves its date through map conversion', () {
    final date = DateTime.utc(2026, 10, 12, 12);
    final transaction = StockTransaction(id: 3, productId: 7, productName: 'Rice', type: 'in', quantity: 20, unitPrice: 42.5, notes: 'Initial stock', date: date);
    final restored = StockTransaction.fromMap(transaction.toMap());
    expect(restored.productId, 7);
    expect(restored.quantity, 20);
    expect(restored.date, date);
  });
}

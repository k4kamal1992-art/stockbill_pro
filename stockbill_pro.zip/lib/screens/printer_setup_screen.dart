import 'package:flutter/material.dart';
import 'package:bluetooth_print/bluetooth_print.dart';
import 'package:bluetooth_print/bluetooth_print_model.dart';

class PrinterSetupScreen extends StatefulWidget {
  const PrinterSetupScreen({super.key});

  @override
  State<PrinterSetupScreen> createState() => _PrinterSetupScreenState();
}

class _PrinterSetupScreenState extends State<PrinterSetupScreen> {
  final BluetoothPrint _bluetoothPrint = BluetoothPrint.instance;
  List<BluetoothDevice> _devices = [];
  bool _isScanning = false;
  BluetoothDevice? _connectedDevice;

  @override
  void initState() {
    super.initState();
    _initPrinter();
  }

  Future<void> _initPrinter() async {
    _bluetoothPrint.state.listen((state) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  Future<void> _scanDevices() async {
    setState(() => _isScanning = true);
    _devices = await _bluetoothPrint.scanResults.first;
    setState(() => _isScanning = false);
  }

  Future<void> _connectDevice(BluetoothDevice device) async {
    await _bluetoothPrint.connect(device);
    setState(() => _connectedDevice = device);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Connected to ${device.name}')),
      );
    }
  }

  Future<void> _disconnectDevice() async {
    await _bluetoothPrint.disconnect();
    setState(() => _connectedDevice = null);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Printer disconnected')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bluetooth Printer'),
      ),
      body: Column(
        children: [
          // Status Card
          Card(
            margin: const EdgeInsets.all(12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    _connectedDevice != null ? Icons.print : Icons.print_disabled,
                    color: _connectedDevice != null ? Colors.green : Colors.grey,
                    size: 40,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _connectedDevice != null ? 'Printer Connected' : 'No Printer',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (_connectedDevice != null)
                          Text(
                            _connectedDevice!.name ?? 'Unknown',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                      ],
                    ),
                  ),
                  if (_connectedDevice != null)
                    TextButton.icon(
                      onPressed: _disconnectDevice,
                      icon: const Icon(Icons.disconnect, color: Colors.red),
                      label: const Text('Disconnect', style: TextStyle(color: Colors.red)),
                    ),
                ],
              ),
            ),
          ),

          // Scan Button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isScanning ? null : _scanDevices,
                icon: _isScanning
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.search),
                label: Text(_isScanning ? 'Scanning...' : 'Scan for Printers'),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Devices List
          Expanded(
            child: _devices.isEmpty
                ? const Center(
                    child: Text(
                      'No devices found. Tap Scan to find printers.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: _devices.length,
                    itemBuilder: (context, index) {
                      final device = _devices[index];
                      final isConnected = _connectedDevice?.address == device.address;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        color: isConnected ? Colors.green.shade50 : null,
                        child: ListTile(
                          leading: Icon(
                            Icons.print,
                            color: isConnected ? Colors.green : Colors.blue,
                          ),
                          title: Text(
                            device.name ?? 'Unknown Device',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(device.address ?? ''),
                          trailing: isConnected
                              ? const Chip(
                                  label: Text('Connected'),
                                  backgroundColor: Colors.green,
                                  labelStyle: TextStyle(color: Colors.white),
                                )
                              : ElevatedButton(
                                  onPressed: () => _connectDevice(device),
                                  child: const Text('Connect'),
                                ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

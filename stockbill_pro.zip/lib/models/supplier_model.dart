class Supplier {
  final int? id;
  final String name;
  final String? phone;
  final String? email;
  final String? address;
  final String? companyName;
  final double? dueAmount;

  Supplier({
    this.id,
    required this.name,
    this.phone,
    this.email,
    this.address,
    this.companyName,
    this.dueAmount,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'email': email,
      'address': address,
      'companyName': companyName,
      'dueAmount': dueAmount,
    };
  }

  factory Supplier.fromMap(Map<String, dynamic> map) {
    return Supplier(
      id: map['id'] as int?,
      name: map['name'] as String,
      phone: map['phone'] as String?,
      email: map['email'] as String?,
      address: map['address'] as String?,
      companyName: map['companyName'] as String?,
      dueAmount: map['dueAmount'] as double?,
    );
  }
}

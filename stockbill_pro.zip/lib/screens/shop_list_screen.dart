import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/shop_provider.dart';
import '../models/shop_model.dart';

class ShopListScreen extends StatefulWidget {
  const ShopListScreen({super.key});

  @override
  State<ShopListScreen> createState() => _ShopListScreenState();
}

class _ShopListScreenState extends State<ShopListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ShopProvider>().loadShops();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shops')),
      body: Consumer<ShopProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          final shops = provider.shops;
          if (shops.isEmpty) {
            return const Center(
              child: Text('No shops yet', style: TextStyle(color: Colors.grey)),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: shops.length,
            itemBuilder: (context, index) {
              final shop = shops[index];
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: shop.isActive ? Colors.green : Colors.grey,
                    child: const Icon(Icons.store, color: Colors.white),
                  ),
                  title: Text(shop.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: shop.address != null ? Text(shop.address!) : null,
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'edit') _showShopDialog(context, shop: shop);
                      if (value == 'delete') _deleteShop(context, shop);
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(value: 'edit', child: Text('Edit')),
                      const PopupMenuItem(value: 'delete', child: Text('Delete', style: TextStyle(color: Colors.red))),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showShopDialog(context),
        icon: const Icon(Icons.add_business),
        label: const Text('Add Shop'),
      ),
    );
  }

  void _showShopDialog(BuildContext context, {Shop? shop}) {
    final isEditing = shop != null;
    final nameCtrl = TextEditingController(text: shop?.name ?? '');
    final addressCtrl = TextEditingController(text: shop?.address ?? '');
    final phoneCtrl = TextEditingController(text: shop?.phone ?? '');
    final gstCtrl = TextEditingController(text: shop?.gstNumber ?? '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(isEditing ? 'Edit Shop' : 'Add Shop'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Shop Name *', prefixIcon: Icon(Icons.store))),
              TextField(controller: addressCtrl, decoration: const InputDecoration(labelText: 'Address', prefixIcon: Icon(Icons.location_on))),
              TextField(controller: phoneCtrl, decoration: const InputDecoration(labelText: 'Phone', prefixIcon: Icon(Icons.phone))),
              TextField(controller: gstCtrl, decoration: const InputDecoration(labelText: 'GST Number', prefixIcon: Icon(Icons.numbers))),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              if (nameCtrl.text.trim().isEmpty) return;
              final newShop = Shop(
                id: shop?.id,
                name: nameCtrl.text.trim(),
                address: addressCtrl.text.trim().isEmpty ? null : addressCtrl.text.trim(),
                phone: phoneCtrl.text.trim().isEmpty ? null : phoneCtrl.text.trim(),
                gstNumber: gstCtrl.text.trim().isEmpty ? null : gstCtrl.text.trim(),
              );
              if (isEditing) {
                context.read<ShopProvider>().updateShop(newShop);
              } else {
                context.read<ShopProvider>().addShop(newShop);
              }
              Navigator.pop(ctx);
            },
            child: Text(isEditing ? 'Update' : 'Save'),
          ),
        ],
      ),
    );
  }

  void _deleteShop(BuildContext context, Shop shop) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Shop'),
        content: Text('Delete "${shop.name}"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              context.read<ShopProvider>().deleteShop(shop.id!);
              Navigator.pop(ctx);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

#!/usr/bin/env python3
"""Idempotent Android Gradle compatibility check for StockBill Pro CI.
This script intentionally preserves the app UI/design and only validates Android config.
"""
from pathlib import Path
import sys


def find_project():
    here = Path.cwd()
    for base in (here, here / "stockbill_final", here / "app"):
        if (base / "pubspec.yaml").is_file() and (base / "android" / "app" / "build.gradle").is_file():
            return base
    for pubspec in here.glob("*/pubspec.yaml"):
        base = pubspec.parent
        if (base / "android" / "app" / "build.gradle").is_file():
            return base
    return None


def main():
    project = find_project()
    if project is None:
        print("ERROR: Could not locate pubspec.yaml and android/app/build.gradle.", file=sys.stderr)
        return 2
    gradle = project / "android" / "app" / "build.gradle"
    settings = project / "android" / "settings.gradle"
    text = gradle.read_text(encoding="utf-8")
    required = [
        ("sourceCompatibility = JavaVersion.VERSION_17", "Java 17 source compatibility"),
        ("targetCompatibility = JavaVersion.VERSION_17", "Java 17 target compatibility"),
        ('jvmTarget = "17"', "Kotlin JVM target 17"),
    ]
    missing = [label for needle, label in required if needle not in text]
    if missing:
        print("ERROR: Android Gradle config is missing: " + ", ".join(missing), file=sys.stderr)
        print("Please review android/app/build.gradle; no automatic design or source changes were made.", file=sys.stderr)
        return 2
    if not settings.is_file():
        print("ERROR: android/settings.gradle is missing.", file=sys.stderr)
        return 2
    print(f"Android Gradle configuration check passed: {project}")
    print("No UI, colors, layouts, or navigation files were changed by this script.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

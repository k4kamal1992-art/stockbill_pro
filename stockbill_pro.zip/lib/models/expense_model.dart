class Expense {
  final int? id;
  final String title;
  final double amount;
  final String? category;
  final String? description;
  final DateTime date;

  Expense({
    this.id,
    required this.title,
    required this.amount,
    this.category,
    this.description,
    required this.date,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'amount': amount,
      'category': category,
      'description': description,
      'date': date.toIso8601String(),
    };
  }

  factory Expense.fromMap(Map<String, dynamic> map) {
    return Expense(
      id: map['id'] as int?,
      title: map['title'] as String,
      amount: map['amount'] as double,
      category: map['category'] as String?,
      description: map['description'] as String?,
      date: DateTime.parse(map['date'] as String),
    );
  }
}

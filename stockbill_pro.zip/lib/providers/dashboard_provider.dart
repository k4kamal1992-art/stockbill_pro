import 'package:flutter/material.dart';
import '../database/database_helper.dart';

class DashboardProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;
  Map<String, dynamic> _stats = {};
  bool _isLoading = false;

  Map<String, dynamic> get stats => _stats;
  bool get isLoading => _isLoading;

  Future<void> loadStats() async {
    _isLoading = true;
    notifyListeners();
    _stats = await _db.getDashboardStats();
    _isLoading = false;
    notifyListeners();
  }
}

import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import '../models/product_model.dart';
import 'add_product_screen.dart';

class BarcodeScannerScreen extends StatefulWidget {
  final bool isForProductAdd;

  const BarcodeScannerScreen({super.key, this.isForProductAdd = false});

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  String? _scannedCode;
  bool _isProcessing = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Barcode'),
        actions: [
          IconButton(
            icon: const Icon(Icons.flash_on),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 5,
            child: MobileScanner(
              onDetect: (capture) {
                if (_isProcessing) return;

                final List<Barcode> barcodes = capture.barcodes;
                if (barcodes.isNotEmpty && barcodes.first.rawValue != null) {
                  setState(() {
                    _isProcessing = true;
                    _scannedCode = barcodes.first.rawValue;
                  });
                  _handleBarcodeScan(_scannedCode!);
                }
              },
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              color: Colors.grey.shade100,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.qr_code_scanner, size: 48, color: Colors.grey),
                  const SizedBox(height: 12),
                  Text(
                    _scannedCode ?? 'Point camera at barcode',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: _scannedCode != null ? FontWeight.bold : FontWeight.normal,
                      color: _scannedCode != null ? Colors.green : Colors.grey,
                    ),
                  ),
                  if (_scannedCode != null) ...[
                    const SizedBox(height: 8),
                    const Text('Processing...', style: TextStyle(color: Colors.blue)),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleBarcodeScan(String barcode) async {
    final productProvider = context.read<ProductProvider>();
    await productProvider.loadProducts();

    final products = productProvider.products;
    final matchingProduct = products.where((p) => p.barcode == barcode).toList();

    if (matchingProduct.isNotEmpty) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Product Found'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Name: ${matchingProduct.first.name}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('Stock: ${matchingProduct.first.stockQuantity} ${matchingProduct.first.unit ?? "pcs"}'),
              Text('Price: Rs. ${matchingProduct.first.salePrice.toStringAsFixed(2)}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                setState(() => _isProcessing = false);
              },
              child: const Text('Scan Again'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                Navigator.pop(context, matchingProduct.first);
              },
              child: const Text('Use This Product'),
            ),
          ],
        ),
      );
    } else {
      if (!mounted) return;
      if (widget.isForProductAdd) {
        Navigator.pop(context, barcode);
      } else {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Product Not Found'),
            content: Text('No product found with barcode: $barcode'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  setState(() => _isProcessing = false);
                },
                child: const Text('Scan Again'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddProductScreen(
                        product: Product(
                          name: '',
                          barcode: barcode,
                          purchasePrice: 0,
                          salePrice: 0,
                          stockQuantity: 0,
                        ),
                      ),
                    ),
                  );
                },
                child: const Text('Add Product'),
              ),
            ],
          ),
        );
      }
    }
  }
}
